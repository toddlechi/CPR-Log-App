import React, { useState, useEffect, useRef } from 'react';
import { Play, Square, Volume2, VolumeX, Activity, Syringe, Wind, Zap, Clock, Download, LogOut, FileText, Database } from 'lucide-react';
import { initAuth, googleSignIn, getAccessToken, logout } from './auth';
import { DoseOption, DrugDefinition, DEFAULT_DRUGS_DB, SPECIES_LIST } from './drugsData';

type LogEvent = {
  id: string;
  time: string;
  type: string;
  detail: string;
  options?: string[];
  // Structured fields for specific event types
  vascular?: {
    size?: string;
    site?: string;
    limb?: string;
  };
  intubation?: {
    tubeType?: string;
    size?: string;
  };
  defib?: {
    joules?: string;
    status?: string;
  };
};

const ACCESS_SIZES = ["14G", "16G", "18G", "20G", "22G", "24G", "26G"];
const ACCESS_SITES = ["Cephalic", "Saphenous", "Jugular", "Intraosseous", "Central"];
const ACCESS_LIMBS = ["RTL", "LTL", "RPL", "LPL", "R Jugular", "L Jugular"];

const RHYTHM_OPTIONS = ["Asystole", "PEA", "VFib", "Pulseless VTach", "ROSC", "Bradycardia"];
const MED_OPTIONS = ["IV", "IO", "IT", "IM"];

const INTUBATION_TYPES = ["ET Tube", "AmbuBag and Mask", "AmbuBag", "Laryngeal Mask/ V-Gel", "Mouth-to-Snout", "Tracheostomy"];
const INTUBATION_SIZES = ["R1", "R2", "R3", "R4"];

const CYCLE_DURATION = 130; // 2 minutes 10 seconds per cycle (includes pulse check)

export default function App() {
  const [sessionActive, setSessionActive] = useState(false);
  const [patient, setPatient] = useState({ name: '', weight: '', species: 'Canine', date: new Date().toISOString().split('T')[0] });
  const [totalTime, setTotalTime] = useState(0);
  const [isAudioMuted, setIsAudioMuted] = useState(false);
  const [logs, setLogs] = useState<LogEvent[]>([]);
  const [user, setUser] = useState<any>(null);
  const [drugsDb, setDrugsDb] = useState<Record<string, DrugDefinition>>(() => {
    const saved = localStorage.getItem('vetcpr_drugs_db_v3');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { console.error(e); }
    }
    return DEFAULT_DRUGS_DB;
  });
  const [showDbEditor, setShowDbEditor] = useState(false);
  const [dbText, setDbText] = useState("");

  const mainAudioRef = useRef<HTMLAudioElement | null>(null);
  const epiAudioRef = useRef<HTMLAudioElement | null>(null);
  const timerRef = useRef<any>(null);
  const epiStartTimeRef = useRef<number | null>(null);
  const [epiCooldown, setEpiCooldown] = useState<number | null>(null);

  // Derived values for cycle
  const cycleCount = Math.floor(totalTime / CYCLE_DURATION) + 1;
  const cycleTime = CYCLE_DURATION - (totalTime % CYCLE_DURATION);

  useEffect(() => {
    const unsubscribe = initAuth(
      (u, token) => setUser(u),
      () => setUser(null)
    );

    const saved = localStorage.getItem('vetcpr_patient');
    if (saved) {
      try { setPatient(JSON.parse(saved)); } catch (e) {}
    }

    const metronomeUrl = "https://dl.dropboxusercontent.com/scl/fi/uafulwut1xnrvryxxqygg/CPR-Metronome-Audacity.mp3?rlkey=qj3xn4dftsubguesprfmwmbwe&st=vrt2zmnt";
    const epiSoundUrl = "https://dl.dropboxusercontent.com/scl/fi/73hpmlq1r2fsy8598n6x2/Epinephrine-Timer.mp3?rlkey=geldmtb5ymw6tk32yba6lf61w&st=ji1vrze3";
    
    mainAudioRef.current = new Audio(metronomeUrl);
    mainAudioRef.current.crossOrigin = "anonymous";
    mainAudioRef.current.loop = true;
    epiAudioRef.current = new Audio(epiSoundUrl);
    epiAudioRef.current.crossOrigin = "anonymous";

    return () => {
      unsubscribe();
      clearInterval(timerRef.current);
    };
  }, []);

  const savePatient = (p: typeof patient) => {
    setPatient(p);
    localStorage.setItem('vetcpr_patient', JSON.stringify(p));
  };

  const handleMuteToggle = () => {
    const nextMute = !isAudioMuted;
    setIsAudioMuted(nextMute);
    if (mainAudioRef.current) mainAudioRef.current.muted = nextMute;
    if (epiAudioRef.current) epiAudioRef.current.muted = nextMute;
  };

  const addLog = (type: string, detail: string = '', options?: string[], extra?: Partial<LogEvent>) => {
    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const newLog: LogEvent = { 
      id: Date.now().toString() + Math.random(), 
      time: timeStr, 
      type, 
      detail, 
      options,
      ...extra 
    };
    setLogs(prev => [newLog, ...prev]);
  };

  const updateLogDetail = (id: string, detail: string) => {
    setLogs(prev => prev.map(l => l.id === id ? { ...l, detail } : l));
  };

  const updateVascularLog = (id: string, field: 'size' | 'site' | 'limb', value: string) => {
    setLogs(prev => prev.map(l => {
      if (l.id !== id) return l;
      const v = { ...(l.vascular || {}), [field]: value };
      const parts = [v.size, v.site, v.limb].filter(Boolean);
      return { ...l, vascular: v, detail: parts.join(' - ') };
    }));
  };

  const updateIntubationLog = (id: string, field: 'tubeType' | 'size', value: string) => {
    setLogs(prev => prev.map(l => {
      if (l.id !== id) return l;
      const intu = { ...(l.intubation || {}), [field]: value };
      const parts = [intu.tubeType, intu.size].filter(Boolean);
      return { ...l, intubation: intu, detail: parts.join(' - ') };
    }));
  };

  const updateDefibLog = (id: string, joules: string) => {
    setLogs(prev => prev.map(l => {
      if (l.id !== id) return l;
      const def = { joules, status: 'Delivered' };
      const jText = joules ? `${joules} J` : '';
      const detail = jText ? `${jText} Delivered` : 'Delivered';
      return { ...l, defib: def, detail };
    }));
  };

  const deleteLog = (id: string) => {
    setLogs(prev => prev.filter(l => l.id !== id));
  };

  const startCode = () => {
    setSessionActive(true);
    setTotalTime(0);
    setLogs([]);
    epiStartTimeRef.current = null;
    setEpiCooldown(null);

    addLog("CODE STARTED", `Species: ${patient.species}, Weight: ${patient.weight || 'N/A'} kg`);

    if (mainAudioRef.current) {
      mainAudioRef.current.currentTime = 0;
      mainAudioRef.current.muted = isAudioMuted;
      mainAudioRef.current.play().catch(e => console.error("Audio play failed:", e));
    }

    clearInterval(timerRef.current);

    timerRef.current = setInterval(() => {
      setTotalTime(prev => prev + 1);
      if (epiStartTimeRef.current) {
        const elapsed = Math.floor((Date.now() - epiStartTimeRef.current) / 1000);
        const remaining = 240 - elapsed;
        if (remaining <= 0) {
          setEpiCooldown(null);
        } else {
          setEpiCooldown(remaining);
        }
      }
    }, 1000);
  };

  const stopCode = () => {
    setSessionActive(false);
    clearInterval(timerRef.current);
    if (mainAudioRef.current) {
      mainAudioRef.current.pause();
      mainAudioRef.current.currentTime = 0;
    }
    if (epiAudioRef.current) {
      epiAudioRef.current.pause();
      epiAudioRef.current.currentTime = 0;
    }
    addLog("CODE STOPPED", `Stopped explicitly.`);
  };

  const getDoseOptions = (dbEntry: any, species: string): DoseOption[] => {
    if (!dbEntry || !dbEntry.doses) return [];
    const speciesDose = dbEntry.doses[species];
    if (!speciesDose) return [];

    if (Array.isArray(speciesDose)) {
      return speciesDose.map((opt: any) => {
        if (typeof opt === 'number') return { dose: opt, route: 'IV/IO', label: '' };
        return { dose: opt.dose, route: opt.route || 'IV/IO', label: opt.label || '', description: opt.description || '' };
      });
    }

    if (typeof speciesDose === 'object') {
      if ('dose' in speciesDose && typeof speciesDose.dose === 'number') {
        return [{ dose: speciesDose.dose, route: speciesDose.route || 'IV/IO', label: speciesDose.label || '', description: speciesDose.description || '' }];
      }
      const keys = Object.keys(speciesDose);
      if (keys.length > 0) {
        return keys.map(k => {
          const item = speciesDose[k];
          if (typeof item === 'number') return { dose: item, route: 'IV/IO', label: k };
          return { dose: item.dose, route: item.route || 'IV/IO', label: item.label || k, description: item.description || '' };
        });
      }
    }

    if (typeof speciesDose === 'number') {
      return [{ dose: speciesDose, route: 'IV/IO', label: '' }];
    }

    return [];
  };

  const calculateDoseDetail = (drugName: string, db: any, opt: DoseOption, weight: number) => {
    const baseDrug = drugName.split(' (')[0];
    const unitPrefix = db.unit.split('/')[0];
    const doseMg = weight * opt.dose;
    const volMl = doseMg / db.concentration;
    
    const formattedDoseMg = Number.isInteger(doseMg * 100) ? doseMg.toFixed(2) : doseMg.toFixed(3);
    const formattedVol = volMl.toFixed(2);
    const labelSuffix = opt.label ? ` [${opt.label}]` : '';
    const routeSuffix = opt.route ? ` ${opt.route}` : '';
    
    return {
      baseDrug,
      volMl,
      formattedVol: `${formattedVol} mL`,
      doseMg,
      formattedDoseMg: `${formattedDoseMg} ${unitPrefix}`,
      normalizedDose: `(${opt.dose} ${unitPrefix}/kg)`,
      route: opt.route || 'IV/IO',
      label: opt.label || '',
      logDetail: `${formattedDoseMg} ${unitPrefix} (${formattedVol} mL)${routeSuffix}${labelSuffix}`
    };
  };

  const administerDrug = (drugName: string, opt: DoseOption) => {
    const w = parseFloat(patient.weight);
    const db = drugsDb[drugName];
    if (!db) return;
    
    const baseDrug = drugName.split(' (')[0];
    const isEpi = baseDrug.toLowerCase().includes('epinephrine');
    
    let detail = '';
    const availableOptions: string[] = [];
    
    if (!isNaN(w) && w > 0) {
      const calc = calculateDoseDetail(drugName, db, opt, w);
      detail = calc.logDetail;
    } else {
      detail = `${opt.dose} ${db.unit.split('/')[0]}/kg ${opt.route || ''} ${opt.label ? '[' + opt.label + ']' : ''}`;
    }

    const allOpts = getDoseOptions(db, patient.species);
    allOpts.forEach(otherOpt => {
      if (!isNaN(w) && w > 0) {
        const otherCalc = calculateDoseDetail(drugName, db, otherOpt, w);
        availableOptions.push(otherCalc.logDetail);
      } else {
        availableOptions.push(`${otherOpt.dose} ${db.unit.split('/')[0]}/kg ${otherOpt.route || ''} ${otherOpt.label ? '[' + otherOpt.label + ']' : ''}`);
      }
    });
    
    MED_OPTIONS.forEach(r => {
      if (!availableOptions.includes(r)) availableOptions.push(r);
    });
    
    const logTitle = baseDrug;
    addLog(logTitle, detail, availableOptions);
    
    if (isEpi) {
      epiStartTimeRef.current = Date.now();
      if (epiAudioRef.current) {
        epiAudioRef.current.currentTime = 0;
        epiAudioRef.current.play().catch(e => console.error("Epi audio play failed:", e));
      }
    }
  };

  const resetDbToDefaults = () => {
    if (window.confirm("Reset drug database to the default RECOVER & exotic CPR dosages?")) {
      setDrugsDb(DEFAULT_DRUGS_DB);
      setDbText(JSON.stringify(DEFAULT_DRUGS_DB, null, 2));
      localStorage.setItem('vetcpr_drugs_db_v3', JSON.stringify(DEFAULT_DRUGS_DB));
    }
  };

  const formatTime = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const exportGoogleSheets = async () => {
    if (!user) {
      try { await googleSignIn(); } catch (err) { alert("Google Sign-In failed."); return; }
    }
    const token = await getAccessToken();
    if (!token) { alert("Missing Google access token."); return; }

    try {
      const sheetTitle = `CPR Log - ${patient.name || 'Patient'} - ${patient.date}`;
      const createRes = await fetch("https://sheets.googleapis.com/v4/spreadsheets", {
        method: "POST",
        headers: { "Authorization": `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({ properties: { title: sheetTitle } })
      });
      const sheetData = await createRes.json();
      const spreadsheetId = sheetData.spreadsheetId;

      const rows = [
        ["Patient Name", patient.name, "Date", patient.date],
        ["Species", patient.species, "Weight (kg)", patient.weight],
        [],
        ["Timestamp", "Event Type", "Details / Administration"]
      ];

      [...logs].reverse().forEach(l => {
        rows.push([l.time, l.type, l.detail]);
      });

      await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/A1:append?valueInputOption=USER_ENTERED`, {
        method: "POST",
        headers: { "Authorization": `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({ values: rows })
      });

      window.open(`https://docs.google.com/spreadsheets/d/${spreadsheetId}`, "_blank");
    } catch (e: any) {
      alert(`Error exporting to sheets: ${e.message}`);
    }
  };

  const exportPdf = () => {
    window.print();
  };

  const openDbEditor = () => {
    setDbText(JSON.stringify(drugsDb, null, 2));
    setShowDbEditor(true);
  };

  const saveDb = () => {
    try {
      const parsed = JSON.parse(dbText);
      setDrugsDb(parsed);
      localStorage.setItem('vetcpr_drugs_db_v3', dbText);
      setShowDbEditor(false);
    } catch (e) {
      alert("Invalid JSON format. Please verify syntax.");
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col font-sans">
      {/* Top Navbar */}
      <header className="bg-slate-800/80 border-b border-slate-700 px-6 py-3 flex items-center justify-between shadow-md">
        <div className="flex items-center gap-3">
          <Activity className="w-7 h-7 text-rose-500 animate-pulse" />
          <h1 className="text-xl font-black tracking-tight text-white uppercase">VetCPR Metronome</h1>
        </div>

        <div className="flex items-center gap-3">
          <button onClick={openDbEditor} className="p-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-200 flex items-center gap-1.5 text-sm font-semibold transition cursor-pointer">
            <Database className="w-4 h-4 text-blue-400" /> Database Editor
          </button>
          
          <button onClick={handleMuteToggle} className={`p-2 rounded-lg ${isAudioMuted ? 'bg-rose-950/60 text-rose-400 border border-rose-800' : 'bg-slate-700 hover:bg-slate-600 text-slate-200'} transition cursor-pointer`}>
            {isAudioMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
          </button>

          {user ? (
            <button onClick={logout} className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-xs text-slate-300 transition cursor-pointer">
              <LogOut className="w-4 h-4" /> {user.displayName?.split(' ')[0] || 'User'}
            </button>
          ) : (
            <button onClick={googleSignIn} className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow transition cursor-pointer">
              Google Login
            </button>
          )}
        </div>
      </header>

      {/* Main Grid */}
      <div className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column (Patient Info, Timers, Actions) */}
        <div className="lg:col-span-8 flex flex-col gap-6">
          
          {/* Patient Details Banner */}
          <div className="bg-slate-800/60 border border-slate-700/80 rounded-2xl p-4 shadow-sm grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <label className="text-xs uppercase text-slate-400 font-bold block mb-1">Patient Name</label>
              <input 
                type="text" 
                placeholder="e.g. Bella" 
                value={patient.name}
                onChange={e => savePatient({ ...patient, name: e.target.value })}
                className="w-full bg-slate-900/90 border border-slate-700 rounded-lg px-3 py-2 text-white font-medium focus:border-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="text-xs uppercase text-slate-400 font-bold block mb-1">Species</label>
              <select 
                value={patient.species}
                onChange={e => savePatient({ ...patient, species: e.target.value })}
                className="w-full bg-slate-900/90 border border-slate-700 rounded-lg px-3 py-2 text-white font-medium focus:border-blue-500 outline-none cursor-pointer"
              >
                {SPECIES_LIST.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs uppercase text-slate-400 font-bold block mb-1">Weight (kg)</label>
              <input 
                type="number" 
                step="0.01" 
                placeholder="e.g. 10.5" 
                value={patient.weight}
                onChange={e => savePatient({ ...patient, weight: e.target.value })}
                className="w-full bg-slate-900/90 border border-slate-700 rounded-lg px-3 py-2 text-white font-bold focus:border-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="text-xs uppercase text-slate-400 font-bold block mb-1">Date</label>
              <input 
                type="date" 
                value={patient.date}
                onChange={e => savePatient({ ...patient, date: e.target.value })}
                className="w-full bg-slate-900/90 border border-slate-700 rounded-lg px-3 py-2 text-white font-medium focus:border-blue-500 outline-none"
              />
            </div>
          </div>

          {/* Timers Bar */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            {/* CPR Cycle (2m 10s) */}
            <div className={`p-4 rounded-2xl border flex flex-col items-center justify-center transition-all ${sessionActive ? 'bg-rose-950/30 border-rose-500/50 shadow-rose-900/20 shadow-lg' : 'bg-slate-800/40 border-slate-700'}`}>
              <div className="text-xs uppercase font-extrabold tracking-widest text-slate-400 mb-1 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-rose-400" /> Cycle {cycleCount} (2m 10s)
              </div>
              <div className="text-4xl font-mono font-black tracking-tight text-rose-400">
                {formatTime(cycleTime)}
              </div>
            </div>

            {/* Total Elapsed */}
            <div className="p-4 rounded-2xl border border-slate-700 bg-slate-800/40 flex flex-col items-center justify-center">
              <div className="text-xs uppercase font-extrabold tracking-widest text-slate-400 mb-1 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-blue-400" /> Total Elapsed
              </div>
              <div className="text-4xl font-mono font-black tracking-tight text-white">
                {formatTime(totalTime)}
              </div>
            </div>

            {/* Epinephrine Cooldown */}
            <div className={`p-4 rounded-2xl border flex flex-col items-center justify-center transition-all ${epiCooldown !== null ? 'bg-amber-950/30 border-amber-500/50 text-amber-300 shadow-amber-900/20 shadow-lg' : 'bg-slate-800/40 border-slate-700 text-slate-400'}`}>
              <div className="text-xs uppercase font-extrabold tracking-widest mb-1 flex items-center gap-1.5">
                <Zap className="w-4 h-4 text-amber-400" /> Epi Cooldown (4m)
              </div>
              <div className="text-4xl font-mono font-black tracking-tight">
                {epiCooldown !== null ? formatTime(epiCooldown) : "READY"}
              </div>
            </div>
          </div>

          {/* Start / Stop Control */}
          <div className="flex gap-4">
            {!sessionActive ? (
              <button 
                onClick={startCode} 
                className="flex-1 py-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-2xl font-black text-xl flex items-center justify-center gap-3 shadow-lg shadow-emerald-950/40 active:scale-[0.99] transition cursor-pointer"
              >
                <Play className="w-7 h-7 fill-current" /> START CPR CODE
              </button>
            ) : (
              <button 
                onClick={stopCode} 
                className="flex-1 py-4 bg-rose-600 hover:bg-rose-500 text-white rounded-2xl font-black text-xl flex items-center justify-center gap-3 shadow-lg shadow-rose-950/40 active:scale-[0.99] transition cursor-pointer"
              >
                <Square className="w-7 h-7 fill-current" /> STOP CODE
              </button>
            )}
          </div>

          {/* Drug & Action Matrix */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            <button 
              onClick={() => addLog("Intubation", "", undefined, { intubation: { tubeType: '', size: '' } })} 
              className="bg-cyan-600/20 hover:bg-cyan-600/30 border border-cyan-500/50 text-cyan-400 p-4 rounded-xl flex flex-col items-center justify-center gap-2 transition-colors active:scale-95 cursor-pointer"
            >
              <Wind className="w-8 h-8" /><span className="font-bold">Intubation</span>
            </button>
            <button 
              onClick={() => addLog("Vascular Access", "", undefined, { vascular: { size: '', site: '', limb: '' } })} 
              className="bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/50 text-blue-400 p-4 rounded-xl flex flex-col items-center justify-center gap-2 transition-colors active:scale-95 cursor-pointer"
            >
              <Syringe className="w-8 h-8" /><span className="font-bold">Vascular Access</span>
            </button>
            <button 
              onClick={() => addLog("Rhythm Check", "", RHYTHM_OPTIONS)} 
              className="bg-green-600/20 hover:bg-green-600/30 border border-green-500/50 text-green-400 p-4 rounded-xl flex flex-col items-center justify-center gap-2 transition-colors active:scale-95 cursor-pointer"
            >
              <Activity className="w-8 h-8" /><span className="font-bold">Rhythm Check</span>
            </button>
            <button 
              onClick={() => {
                const w = parseFloat(patient.weight);
                const hasDelivered = logs.some(l => l.type === "Defibrillation" && (l.detail.toLowerCase().includes("delivered") || l.defib?.status === "Delivered"));
                const multiplier = hasDelivered ? 4 : 2;
                const recJoules = !isNaN(w) && w > 0 ? (w * multiplier).toFixed(1) : null;
                const noteText = recJoules ? `Rec: ${recJoules} J (${multiplier} J/kg)` : `Rec: ${multiplier} J/kg`;
                addLog("Defibrillation", "", undefined, { defib: { joules: '', status: 'Delivered' }, options: [noteText] });
              }} 
              className="bg-orange-600/20 hover:bg-orange-600/30 border border-orange-500/50 text-orange-400 p-4 rounded-xl flex flex-col items-center justify-center gap-2 transition-colors active:scale-95 cursor-pointer"
            >
              <Zap className="w-8 h-8" />
              <div className="flex flex-col items-center">
                <span className="font-bold">Defibrillation</span>
                {(() => {
                  const w = parseFloat(patient.weight);
                  const hasDelivered = logs.some(l => l.type === "Defibrillation" && (l.detail.toLowerCase().includes("delivered") || l.defib?.status === "Delivered"));
                  const multiplier = hasDelivered ? 4 : 2;
                  const recJ = !isNaN(w) && w > 0 ? `${(w * multiplier).toFixed(1)} J` : `${multiplier} J/kg`;
                  return <span className="text-[11px] text-orange-300 font-semibold opacity-90">({recJ} - {hasDelivered ? 'Subsequent' : '1st shock'})</span>;
                })()}
              </div>
            </button>

            {/* Note Button */}
            <button 
              onClick={() => {
                addLog("Note", "");
              }} 
              className="bg-slate-700/40 hover:bg-slate-700/60 border border-slate-600 text-slate-300 p-4 rounded-xl flex flex-col items-center justify-center gap-2 transition-colors active:scale-95 cursor-pointer"
            >
              <FileText className="w-8 h-8 text-slate-400" /><span className="font-bold">Add Note</span>
            </button>

            {Object.keys(drugsDb).map(drugName => {
                const db = drugsDb[drugName];
                const doseOptions = getDoseOptions(db, patient.species);
                const hasDose = doseOptions.length > 0;
                
                const isEpi = drugName.toLowerCase().includes('epinephrine');
                const isAtropine = drugName.toLowerCase().includes('atropine');
                
                let themeBorder = 'border-yellow-500/50';
                let themeBg = 'bg-yellow-600/20';
                let themeText = 'text-yellow-400';
                let subBtnHover = 'hover:bg-yellow-500/30 bg-yellow-950/40 border-yellow-500/40 text-yellow-200';
                
                if (isEpi) {
                    themeBorder = 'border-red-500/50';
                    themeBg = 'bg-red-600/20';
                    themeText = 'text-red-400';
                    subBtnHover = 'hover:bg-red-500/30 bg-red-950/40 border-red-500/40 text-red-200';
                } else if (isAtropine) {
                    themeBorder = 'border-purple-500/50';
                    themeBg = 'bg-purple-600/20';
                    themeText = 'text-purple-400';
                    subBtnHover = 'hover:bg-purple-500/30 bg-purple-950/40 border-purple-500/40 text-purple-200';
                }
                
                const w = parseFloat(patient.weight);
                const baseName = drugName.split(' (')[0];

                if (!hasDose) {
                  return (
                    <div 
                      key={drugName}
                      className="p-4 rounded-xl flex flex-col items-center justify-center gap-1 border bg-slate-800/40 border-slate-700 text-slate-600 opacity-50 cursor-not-allowed"
                    >
                      <span className="text-xl font-bold text-center leading-tight">{baseName}</span>
                      <span className="text-xs italic mt-1">No {patient.species} dose</span>
                    </div>
                  );
                }

                if (doseOptions.length > 1) {
                  return (
                    <div 
                      key={drugName}
                      className={`rounded-xl border ${themeBorder} ${themeBg} p-3 flex flex-col justify-between gap-2 shadow-lg col-span-2 md:col-span-2`}
                    >
                      <div className="flex items-center justify-between border-b border-white/10 pb-1.5 px-1">
                        <span className={`text-xl font-bold ${themeText}`}>{baseName}</span>
                        <span className="text-xs uppercase tracking-wider opacity-60 font-semibold">{doseOptions.length} Options</span>
                      </div>
                      
                      <div className={`grid ${doseOptions.length === 2 ? 'grid-cols-2' : doseOptions.length === 3 ? 'grid-cols-3' : 'grid-cols-2 md:grid-cols-4'} gap-2`}>
                        {doseOptions.map((opt, idx) => {
                          const calc = !isNaN(w) && w > 0 ? calculateDoseDetail(drugName, db, opt, w) : null;
                          const optLabel = opt.label || `Option ${idx + 1}`;
                          
                          return (
                            <div key={idx} className="relative group/tooltip flex">
                              <button
                                onClick={() => administerDrug(drugName, opt)}
                                title={opt.description ? `${optLabel}: ${opt.description}` : undefined}
                                className={`w-full p-2.5 rounded-lg border flex flex-col items-center justify-center gap-0.5 transition-all active:scale-95 text-center cursor-pointer ${subBtnHover}`}
                              >
                                <div className="flex items-center justify-center gap-1 flex-wrap">
                                  <span className="font-bold text-xs uppercase tracking-wide">{optLabel}</span>
                                  {opt.route && <span className="text-[10px] bg-black/40 px-1.5 py-0.2 rounded opacity-80">{opt.route}</span>}
                                </div>
                                {calc ? (
                                  <>
                                    <span className="text-lg font-bold text-white leading-tight mt-0.5">{calc.formattedVol}</span>
                                    <span className="text-xs opacity-75">{calc.normalizedDose}</span>
                                  </>
                                ) : (
                                  <span className="text-xs opacity-75 mt-1">({opt.dose} {db.unit.split('/')[0]}/kg)</span>
                                )}
                              </button>

                              {/* Hover description popup card */}
                              {opt.description && (
                                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 hidden group-hover/tooltip:flex flex-col z-30 w-56 p-2 bg-slate-950/95 border border-slate-600 rounded-lg shadow-xl text-left pointer-events-none transition-opacity">
                                  <div className="text-[11px] font-bold text-amber-300 flex items-center gap-1">
                                    <span>ℹ️ {optLabel}</span>
                                  </div>
                                  <div className="text-[11px] text-slate-200 mt-0.5 leading-snug">
                                    {opt.description}
                                  </div>
                                  <div className="text-[9px] text-slate-400 mt-1 pt-1 border-t border-slate-800">
                                    Dose: {opt.dose} {db.unit.split('/')[0]}/kg {opt.route ? `(${opt.route})` : ''}
                                  </div>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                }

                const singleOpt = doseOptions[0];
                const singleCalc = !isNaN(w) && w > 0 ? calculateDoseDetail(drugName, db, singleOpt, w) : null;

                return (
                  <div key={drugName} className="relative group/tooltip flex">
                    <button 
                      onClick={() => administerDrug(drugName, singleOpt)}
                      title={singleOpt.description ? `${baseName}: ${singleOpt.description}` : undefined}
                      className={`w-full p-4 rounded-xl flex flex-col items-center justify-center gap-1 transition-colors active:scale-95 border ${themeBg} ${themeBorder} ${themeText} hover:brightness-110 cursor-pointer`}
                    >
                      <span className="text-xl font-bold text-center leading-tight">{baseName}</span>
                      {singleCalc ? (
                        <>
                          <span className="text-lg font-bold text-white">{singleCalc.formattedVol}</span>
                          <span className="text-sm opacity-70">
                            {singleCalc.normalizedDose} {singleOpt.route ? `[${singleOpt.route}]` : ''}
                          </span>
                        </>
                      ) : (
                        <span className="text-sm opacity-70">
                          ({singleOpt.dose} {db.unit.split('/')[0]}/kg) {singleOpt.route ? `[${singleOpt.route}]` : ''}
                        </span>
                      )}
                    </button>

                    {/* Hover description popup card */}
                    {singleOpt.description && (
                      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 hidden group-hover/tooltip:flex flex-col z-30 w-60 p-2.5 bg-slate-950/95 border border-slate-600 rounded-lg shadow-xl text-left pointer-events-none transition-opacity">
                        <div className="text-xs font-bold text-amber-300 flex items-center gap-1">
                          <span>ℹ️ {baseName} {singleOpt.label ? `(${singleOpt.label})` : ''}</span>
                        </div>
                        <div className="text-xs text-slate-200 mt-1 leading-snug">
                          {singleOpt.description}
                        </div>
                        <div className="text-[10px] text-slate-400 mt-1.5 pt-1 border-t border-slate-800">
                          Dose: {singleOpt.dose} {db.unit.split('/')[0]}/kg {singleOpt.route ? `(${singleOpt.route})` : ''}
                        </div>
                      </div>
                    )}
                  </div>
                );
            })}
          </div>

        </div>

        {/* Right Column (Live Log) */}
        <div className="lg:col-span-4 flex flex-col bg-slate-800/50 border border-slate-700/80 rounded-2xl p-4 shadow-sm overflow-hidden min-h-[500px]">
          <div className="flex items-center justify-between pb-3 border-b border-slate-700">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <FileText className="w-5 h-5 text-blue-400" /> Event Timeline
            </h2>
            <div className="flex gap-2">
              <button onClick={exportGoogleSheets} title="Export to Sheets" className="p-1.5 bg-emerald-600/30 hover:bg-emerald-600/50 border border-emerald-500/50 rounded-lg text-emerald-300 transition cursor-pointer">
                <Download className="w-4 h-4" />
              </button>
              <button onClick={exportPdf} title="Print/PDF" className="p-1.5 bg-slate-700 hover:bg-slate-600 rounded-lg text-slate-300 transition cursor-pointer">
                <FileText className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto mt-3 space-y-2.5 pr-1">
            {logs.length === 0 ? (
              <div className="text-center text-slate-500 italic py-12 text-sm">
                No events recorded yet. Start code or click actions to log.
              </div>
            ) : (
              logs.map(log => (
                <div key={log.id} className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-700/60 flex flex-col gap-1.5 text-xs">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-rose-400 bg-rose-950/60 px-1.5 py-0.5 rounded border border-rose-800/40">
                        {log.time}
                      </span>
                      <span className="font-bold text-slate-200 uppercase tracking-wide">
                        {log.type}
                      </span>
                    </div>
                    <button onClick={() => deleteLog(log.id)} className="text-slate-500 hover:text-rose-400 cursor-pointer font-bold px-1">
                      ×
                    </button>
                  </div>
                  
                  <div className="mt-1">
                    {/* 1. Vascular Access: 3 combo/inputs on one line with datalists (Size, Type/Site, Location/Limb) */}
                    {log.type === "Vascular Access" && (
                      <div className="grid grid-cols-3 gap-1.5">
                        <div className="relative">
                          <input
                            type="text"
                            value={log.vascular?.size || ''}
                            onChange={e => updateVascularLog(log.id, 'size', e.target.value)}
                            placeholder="Size..."
                            list={`vasc-size-${log.id}`}
                            className="w-full bg-slate-950/90 border border-slate-700 rounded px-1.5 py-1 text-slate-200 focus:border-blue-500 outline-none text-[11px]"
                          />
                          <datalist id={`vasc-size-${log.id}`}>
                            {ACCESS_SIZES.map(s => <option key={s} value={s} />)}
                          </datalist>
                        </div>

                        <div className="relative">
                          <input
                            type="text"
                            value={log.vascular?.site || ''}
                            onChange={e => updateVascularLog(log.id, 'site', e.target.value)}
                            placeholder="Type..."
                            list={`vasc-site-${log.id}`}
                            className="w-full bg-slate-950/90 border border-slate-700 rounded px-1.5 py-1 text-slate-200 focus:border-blue-500 outline-none text-[11px]"
                          />
                          <datalist id={`vasc-site-${log.id}`}>
                            {ACCESS_SITES.map(s => <option key={s} value={s} />)}
                          </datalist>
                        </div>

                        <div className="relative">
                          <input
                            type="text"
                            value={log.vascular?.limb || ''}
                            onChange={e => updateVascularLog(log.id, 'limb', e.target.value)}
                            placeholder="Location..."
                            list={`vasc-limb-${log.id}`}
                            className="w-full bg-slate-950/90 border border-slate-700 rounded px-1.5 py-1 text-slate-200 focus:border-blue-500 outline-none text-[11px]"
                          />
                          <datalist id={`vasc-limb-${log.id}`}>
                            {ACCESS_LIMBS.map(l => <option key={l} value={l} />)}
                          </datalist>
                        </div>
                      </div>
                    )}

                    {/* 2. Intubation: 2 combo/inputs on one line with datalists (Type, Size) */}
                    {log.type === "Intubation" && (
                      <div className="grid grid-cols-2 gap-1.5">
                        <div className="relative">
                          <input
                            type="text"
                            value={log.intubation?.tubeType || ''}
                            onChange={e => updateIntubationLog(log.id, 'tubeType', e.target.value)}
                            placeholder="Type..."
                            list={`int-type-${log.id}`}
                            className="w-full bg-slate-950/90 border border-slate-700 rounded px-1.5 py-1 text-slate-200 focus:border-cyan-500 outline-none text-[11px]"
                          />
                          <datalist id={`int-type-${log.id}`}>
                            {INTUBATION_TYPES.map(t => <option key={t} value={t} />)}
                          </datalist>
                        </div>

                        <div className="relative">
                          <input 
                            type="text" 
                            value={log.intubation?.size || ''}
                            onChange={e => updateIntubationLog(log.id, 'size', e.target.value)}
                            placeholder="Size (e.g. 7.5 mm or R1)..."
                            list={`int-size-${log.id}`}
                            className="w-full bg-slate-950/90 border border-slate-700 rounded px-1.5 py-1 text-slate-200 focus:border-cyan-500 outline-none text-[11px]"
                          />
                          <datalist id={`int-size-${log.id}`}>
                            {INTUBATION_SIZES.map(s => <option key={s} value={s} />)}
                          </datalist>
                        </div>
                      </div>
                    )}

                    {/* 3. Defibrillation: Slot for numeric value + "Delivered" badge with no dropdown */}
                    {log.type === "Defibrillation" && (
                      <div className="flex flex-col gap-1">
                        <div className="flex items-center gap-2">
                          <div className="flex items-center gap-1 bg-slate-950/90 border border-slate-700 rounded px-2 py-1 flex-1">
                            <input
                              type="number"
                              step="0.1"
                              placeholder="Joules (##.#)"
                              value={log.defib?.joules ?? ''}
                              onChange={e => updateDefibLog(log.id, e.target.value)}
                              className="w-full bg-transparent text-slate-200 focus:outline-none text-[11px] font-mono"
                            />
                            <span className="text-slate-400 text-[10px] font-bold">J</span>
                          </div>
                          <span className="bg-orange-950/80 border border-orange-600/60 text-orange-300 text-[11px] font-semibold px-2.5 py-1 rounded">
                            Delivered
                          </span>
                        </div>
                        {log.options && log.options[0] && (
                          <div className="text-[10px] text-orange-400/90 font-medium px-1">
                            💡 Recommended: {log.options[0]}
                          </div>
                        )}
                      </div>
                    )}

                    {/* 4. Rhythm Check: Editable text input with suggestions datalist */}
                    {log.type === "Rhythm Check" && (
                      <div className="relative">
                        <input
                          type="text"
                          value={log.detail || ''}
                          onChange={e => updateLogDetail(log.id, e.target.value)}
                          placeholder="Select or enter rhythm..."
                          list={`rhythm-${log.id}`}
                          className="w-full bg-slate-950/90 border border-slate-700 rounded px-2 py-1 text-slate-200 focus:border-green-500 outline-none text-xs"
                        />
                        <datalist id={`rhythm-${log.id}`}>
                          {RHYTHM_OPTIONS.map(r => <option key={r} value={r} />)}
                        </datalist>
                      </div>
                    )}

                    {/* 5. Custom Note Log Field */}
                    {log.type === "Note" && (
                      <div className="flex gap-1.5 items-center">
                        <input 
                          type="text" 
                          autoFocus={!log.detail}
                          value={log.detail}
                          onChange={e => updateLogDetail(log.id, e.target.value)}
                          placeholder="Type note here (e.g. CPR paused, pupil dilation, chest compressions rotated)..."
                          className="w-full bg-slate-950/90 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 placeholder:text-slate-500 focus:border-slate-400 outline-none text-xs"
                        />
                      </div>
                    )}

                    {/* 6. Medication and other general logs */}
                    {log.type !== "Vascular Access" && log.type !== "Intubation" && log.type !== "Defibrillation" && log.type !== "Rhythm Check" && log.type !== "Note" && (
                      <div className="flex gap-1.5 items-center">
                        <input 
                          type="text" 
                          value={log.detail}
                          onChange={e => updateLogDetail(log.id, e.target.value)}
                          placeholder="Add details / route..."
                          list={`list-${log.id}`}
                          className="w-full bg-slate-950/70 border border-slate-700/70 rounded px-2 py-1 text-slate-300 focus:border-blue-500 outline-none text-xs"
                        />
                        {log.options && log.options.length > 0 && (
                          <datalist id={`list-${log.id}`}>
                            {log.options.map((opt, i) => <option key={i} value={opt} />)}
                          </datalist>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

      </div>

      {/* Database Editor Modal */}
      {showDbEditor && (
        <div className="fixed inset-0 bg-slate-900/90 backdrop-blur-sm flex items-center justify-center z-50 p-4">
           <div className="bg-slate-800 p-6 rounded-2xl w-full max-w-4xl flex flex-col gap-4 border border-slate-700 shadow-2xl max-h-[90vh]">
              <div className="flex justify-between items-center">
                 <h2 className="text-2xl font-bold text-white flex items-center gap-2"><Database className="text-blue-400"/> Drug Database JSON Editor</h2>
                 <button onClick={() => setShowDbEditor(false)} className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-700 cursor-pointer"><VolumeX className="w-6 h-6 rotate-45" /></button>
              </div>
              <div className="bg-slate-900/70 p-3 rounded-lg border border-slate-700 text-xs text-slate-300 space-y-1">
                 <div className="font-semibold text-blue-400">Supported Species Dosage Formats:</div>
                 <div><strong className="text-slate-200">1. Multiple Doses (Array):</strong> <code className="text-emerald-300">"Canine": [ &#123; "dose": 0.01, "route": "IV/IO", "label": "Low Dose" &#125;, &#123; "dose": 0.1, "route": "IV/IO", "label": "High Dose" &#125; ]</code></div>
                 <div><strong className="text-slate-200">2. Single Dose (Object):</strong> <code className="text-emerald-300">"Canine": &#123; "dose": 0.04, "route": "IV/IO", "label": "Standard" &#125;</code></div>
                 <div><strong className="text-slate-200">3. Direct Number:</strong> <code className="text-emerald-300">"Canine": 0.01</code></div>
              </div>
              <textarea 
                 className="w-full flex-1 min-h-[350px] bg-slate-950 text-emerald-400 font-mono p-4 rounded-xl border border-slate-700 outline-none focus:border-blue-500 text-sm shadow-inner"
                 value={dbText}
                 onChange={e => setDbText(e.target.value)}
              />
              <div className="flex justify-between items-center gap-3 mt-2">
                 <button onClick={resetDbToDefaults} className="px-4 py-2 text-sm font-semibold text-rose-400 hover:bg-rose-950/40 border border-rose-800/50 rounded-lg transition-colors cursor-pointer">Reset to Default RECOVER Doses</button>
                 <div className="flex gap-3">
                   <button onClick={() => setShowDbEditor(false)} className="px-6 py-2.5 font-bold text-slate-300 hover:bg-slate-700 rounded-lg transition-colors cursor-pointer">Cancel</button>
                   <button onClick={saveDb} className="px-6 py-2.5 font-bold bg-blue-600 hover:bg-blue-500 text-white rounded-lg transition-colors shadow-lg cursor-pointer">Save Database</button>
                 </div>
              </div>
           </div>
        </div>
      )}
    </div>
  );
}
