export type DoseOption = {
  dose: number;
  route?: string;
  label?: string;
  description?: string;
};

export type DrugDefinition = {
  concentration: number;
  unit: string;
  doses: Record<string, DoseOption | DoseOption[] | Record<string, DoseOption> | number>;
};

export const SPECIES_LIST = [
  "Canine", "Feline", "Avian", "Rabbit", "Rodent", "Ferret",
  "Reptile", "Amphibian", "Fish", "Miniature Pig", "Sugar Glider",
  "Hedgehog", "Wildlife"
];

const stdEpi: DoseOption[] = [
  { dose: 0.01, route: "IV/IO", label: "Standard" },
  { dose: 0.1, route: "IT", label: "Intratracheal" }
];

export const DEFAULT_DRUGS_DB: Record<string, DrugDefinition> = {
  "Epinephrine (1 mg/mL)": {
    concentration: 1,
    unit: "mg/mL",
    doses: {
      "Canine": stdEpi,
      "Feline": stdEpi,
      "Rabbit": [
        { dose: 0.2, route: "IV", label: "Standard" }
      ],
      "Avian": [
        { dose: 0.1, route: "IV/IO", label: "Standard" },
        { dose: 0.01, route: "IT", label: "Intratracheal" }
      ],
      "Reptile": [
        { dose: 0.5, route: "IV/IO", label: "Standard" },
        { dose: 1, route: "IT", label: "Intratracheal" }
      ],
      "Rodent": [
        { dose: 0.1, route: "IV", label: "Chinchilla, Gerbil, Murine" },
        { dose: 0.003, route: "IV", label: "Guinea Pig" }
      ],
      "Ferret": [
        { dose: 0.02, route: "IV/IM/IT/SC", label: "Standard" }
      ],
      "Sugar Glider": [
        { dose: 0.03, route: "IV", label: "Standard" }
      ],
      "Hedgehog": [
        { dose: 0.03, route: "IV", label: "Standard" }
      ],
      "Miniature Pig": [
        { dose: 0.01, route: "IV/IO", label: "Standard" },
        { dose: 0.1, route: "IT", label: "Intratracheal" }
      ],
      "Amphibian": [{ dose: 0.1, route: "IV/IC/Topical", label: "Standard" }],
      "Fish": [{ dose: 0.1, route: "IV/IC/Gill", label: "Standard" }],
      "Wildlife": [
        { dose: 0.01, route: "IV/IO", label: "Standard" },
        { dose: 0.1, route: "IT", label: "Intratracheal", description: "Dilute in 5-10mL of Saline" }
      ]
    }
  },
  "Atropine (0.54 mg/mL)": {
    concentration: 0.54,
    unit: "mg/mL",
    doses: {
      "Canine": [
        { dose: 0.054, route: "IV/IO", label: "Standard" },
        { dose: 0.2, route: "IT", label: "Intratracheal", description: "Dilute 1:10 in Sterile Saline and Water" }
      ],
      "Feline": [
        { dose: 0.054, route: "IV/IO", label: "Standard" },
        { dose: 0.2, route: "IT", label: "Intratracheal", description: "Dilute 1:10 in Sterile Saline and Water" }
      ],
      "Avian": [
        { dose: 0.04, route: "IV/IM/IO/IT", label: "Low end" },
        { dose: 0.2, route: "IV/IM/IO/IT", label: "High end" },
        { dose: 0.1, route: "IV/IM", label: "Poultry and Waterfowl" }
      ],
      "Reptile": { dose: 0.5, route: "IV/IM/IO/IT", label: "Standard" },
      "Rodent": [
        { dose: 0.2, route: "IV/IM/SC", label: "Chinchilla, Guinea Pig" },
        { dose: 0.4, route: "IV", label: "Gerbil, Murine" }
      ],
      "Ferret": [
        { dose: 0.05, route: "IV", label: "Standard" },
        { dose: 0.1, route: "IT", label: "Intratracheal" }
      ]
    }
  },
  "Amiodarone (50 mg/mL)": {
    concentration: 50,
    unit: "mg/mL",
    doses: {
      "Canine": [
        { dose: 5, route: "IV", label: "If Lidocaine not available", description: "Must use polysorbate 80-free formulation (Nexterone)" }
      ],
      "Feline": { dose: 5, route: "IV", label: "Standard" }
    }
  },
  "Lidocaine (20 mg/mL)": {
    concentration: 20,
    unit: "mg/mL",
    doses: {
      "Canine": { dose: 2, route: "IV/IO", label: "Adjunctive", description: "If refractory to shockable rhythm after 2 defibrillations. Over 2-4m" },
      "Rabbit": { dose: 2, route: "IV", label: "Standard" },
      "Rodent": { dose: 2, route: "IV", label: "Standard" },
      "Ferret": { dose: 1, route: "IV", label: "Standard" }
    }
  },
  "Vasopressin (20 U/mL)": {
    concentration: 20,
    unit: "U/mL",
    doses: {
      "Canine": [
        { dose: 0.8, route: "IV/IO", label: "Adjunctive - Shockable", description: "q3-5m. If refractory to shockable rhythm after first defibrillation" },
        { dose: 1.2, route: "IT", label: "Adjunctive - Shockable", description: "If IV/IO not possible. Dilute in Sterile Saline or Water" },
        { dose: 0.2, route: "IV", label: "Adjunctive - Non-Shockable (0.2 U/kg)", description: "Low end 0.2-0.8 U/kg IV once" },
        { dose: 0.4, route: "IV", label: "Adjunctive - Non-Shockable (0.4 U/kg)", description: "Low end 0.4-0.8 U/kg followed by CRI" },
        { dose: 0.8, route: "IV", label: "Adjunctive - Non-Shockable (0.8 U/kg)", description: "High end 0.2-0.8 U/kg IV once, or 0.4-0.8 U/kg followed by CRI" }
      ],
      "Feline": [
        { dose: 0.8, route: "IV/IO", label: "Adjunctive - Shockable", description: "q3-5m. If refractory to shockable rhythm after first defibrillation" },
        { dose: 1.2, route: "IT", label: "Adjunctive - Shockable", description: "If IV/IO not possible. Dilute in Sterile Saline or Water" },
        { dose: 0.2, route: "IV", label: "Adjunctive - Non-Shockable (0.2 U/kg)", description: "Low end 0.2-0.8 U/kg IV once" },
        { dose: 0.8, route: "IV", label: "Adjunctive - Non-Shockable (0.8 U/kg)", description: "High end 0.2-0.8 U/kg IV once, or 0.4-0.8 U/kg followed by CRI" }
      ],
      "Avian": { dose: 0.8, route: "IV/IO", label: "Standard" },
      "Rabbit": { dose: 0.8, route: "IV/IO", label: "Standard" },
      "Rodent": [
        { dose: 0.8, route: "IV/IO q3-5m", label: "Standard" },
        { dose: 1.2, route: "IT q3-5m", label: "Intratracheal", description: "When IV/IO not possible. Dilute dose in 0.2–0.5 mL/kg of Sterile Saline" }
      ],
      "Ferret": [
        { dose: 0.8, route: "IV/IO q3-5m", label: "Standard" },
        { dose: 1.2, route: "IT q3-5m", label: "Intratracheal", description: "When IV/IO not possible. Dilute dose in 0.2–0.5 mL/kg of Sterile Saline" }
      ],
      "Miniature Pig": [
        { dose: 0.8, route: "IV/IO q3-5m", label: "Standard" },
        { dose: 1.2, route: "IT q3-5m", label: "Intratracheal", description: "When IV/IO not possible. Dilute dose in 0.2–0.5 mL/kg of Sterile Saline" }
      ],
      "Hedgehog": [
        { dose: 0.8, route: "IV/IO q3-5m", label: "Standard" },
        { dose: 1.2, route: "IT q3-5m", label: "Intratracheal", description: "When IV/IO not possible. Dilute dose in 0.2–0.5 mL/kg of Sterile Saline" }
      ],
      "Sugar Glider": [
        { dose: 0.8, route: "IV/IO q3-5m", label: "Standard" },
        { dose: 1.2, route: "IT q3-5m", label: "Intratracheal", description: "When IV/IO not possible. Dilute dose in 0.2–0.5 mL/kg of Sterile Saline" }
      ]
    }
  },
  "Magnesium Sulfate (50%)": {
    concentration: 500,
    unit: "mg/mL",
    doses: {
      "Canine": { dose: 30, route: "IV Slow", label: "Refractory Arrhythmia", description: "0.15–0.3 mEq/kg (~30 mg/kg) IV slow over 5-15m. For refractory VF/VTach or Torsades de Pointes" },
      "Feline": { dose: 30, route: "IV Slow", label: "Refractory Arrhythmia", description: "0.15–0.3 mEq/kg (~30 mg/kg) IV slow over 5-15m. For refractory VF/VTach or Torsades de Pointes" }
    }
  },
  "Atipamezole (5 mg/mL)": {
    concentration: 5,
    unit: "mg/mL",
    doses: {
      "Canine": { dose: 0.1, route: "IM/IV", label: "Reversal" },
      "Feline": { dose: 0.1, route: "IM/IV", label: "Reversal" }
    }
  },
  "Naloxone (0.4 mg/mL)": {
    concentration: 0.4,
    unit: "mg/mL",
    doses: {
      "Canine": [
        { dose: 0.04, route: "IV/IM", label: "Full CPR" },
        { dose: 0.01, route: "IV", label: "Titration" }
      ],
      "Feline": [
        { dose: 0.04, route: "IV/IM", label: "Full CPR" },
        { dose: 0.01, route: "IV", label: "Titration" }
      ],
      "Avian": { dose: 2, route: "IV", label: "Standard" },
      "Rabbit": { dose: 0.1, route: "IV/IM", label: "Standard" },
      "Reptile": { dose: 0.2, route: "SC/IM", label: "Standard" }
    }
  },
  "Flumazenil (0.1 mg/mL)": {
    concentration: 0.1,
    unit: "mg/mL",
    doses: {
      "Canine": { dose: 0.02, route: "IV", label: "Reversal" },
      "Feline": { dose: 0.02, route: "IV", label: "Reversal" },
      "Avian": { dose: 0.1, route: "IM/IV", label: "Standard" },
      "Rabbit": { dose: 0.1, route: "IV", label: "Standard" }
    }
  }
};
